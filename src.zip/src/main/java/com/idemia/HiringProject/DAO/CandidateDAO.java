package com.idemia.HiringProject.DAO;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.Tuple;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.idemia.HiringProject.Entity.Candidate;
import com.idemia.HiringProject.Entity.Requirement;
import com.idemia.HiringProject.form.CandidateForm;
import com.idemia.HiringProject.DAO.ICandidateDAO;

@Transactional
@Repository

public class CandidateDAO implements ICandidateDAO {
	
	@PersistenceContext	
	private EntityManager entityManager;	
	
	public Candidate getCandidateById(int id) {
		return entityManager.find(Candidate.class, id);
	}
	
	public List<Candidate> getCandidateByPanNumber(String panCard) {
		 String hql = "FROM Candidate as can WHERE can.panCard= ?";
		 List<Candidate> ls = new ArrayList<>();
		 ls= entityManager.createQuery(hql).setParameter(1, panCard).getResultList();
		//Query data =  entityManager.createQuery(hql).setParameter(1, panCard);
		// System.out.println(data);
		 return ls;
	}
	
	public List<Candidate> getCandidateByEmailID(String candidateemailID) {
		String hql = "FROM Candidate as can WHERE can.candidateEmailID= ? ";
		 List<Candidate> ls =new ArrayList<>();
		 ls= entityManager.createQuery(hql).setParameter(1, candidateemailID).getResultList();
		 
		 return ls;
	}
	

	
	public List<CandidateForm> getAllCandidate() {
		String hql = "FROM Candidate as can";
		List<CandidateForm> ls=new ArrayList<>();
		ls= entityManager.createQuery(hql).getResultList();
		return ls;
	}

	public String addCandidate(Candidate candidate) throws SQLException{
		try {
			entityManager.persist(candidate);
		
		} catch (Exception e) {
			//TODO Log the database Exception
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateCandidate(CandidateForm candidate) {
		 List<Candidate> can = getCandidateByPanNumber(candidate.getPanCardNumber());
		 Candidate c= can.get(0);
		c.setFirstName(candidate.getFirstName());
		c.setLastName(candidate.getLastName());
		c.setCandidateEmailID(candidate.getMailId());
		c.setMobileNumber(candidate.getMobileNumber());
		entityManager.flush();
	}
	
	public void deleteCandidate(String panCard) {
		entityManager.remove(getCandidateByPanNumber(panCard));
	}
	

	@Override
	public List<String> getRequirementID() {
		String hql = "SELECT R.requirementID FROM Requirement R";
	//	List<String> ls=new ArrayList<>();
	List<String> ls	= entityManager.createQuery(hql).getResultList();
		//System.out.println("Hello");
		//System.out.println(entityManager.createQuery(hql).getResultList());
		return ls;
	}
		
	
	
}