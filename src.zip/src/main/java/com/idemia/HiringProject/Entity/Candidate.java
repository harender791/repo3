package com.idemia.HiringProject.Entity;
/**
 * 
 * @author G521742
 *
 */

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="candidate")
public class Candidate implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	  
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
		private int id;
	
	
//	@Column(name="pancard")
//	private String panCard;
	
	@Column(name="candidateemailID")
	private String candidateEmailID;

	@Column(name="firstname")
	private String firstName;

	@Column(name="lastname")
	private String lastName;
	
	@Column(name="mobilenumber")
	private String mobileNumber;
	
	@Column(name="status")
	private String status;
	
	@Column(name="requirementID")
	private String requirementID;
	
	@OneToOne(cascade =  CascadeType.ALL)
	@JoinColumn(name="pancard")
	private Interview interview;
	
	public Interview getInterview() {
		return interview;
	}



	public void setInterview(Interview interview) {
		this.interview = interview;
	}



	public Candidate() {
		
	}
		

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRequirementID() {
		return requirementID;
	}

	public void setRequirementID(String requirementID) {
		this.requirementID = requirementID;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

//	public String getPanCard() {
//		return panCard;
//	}
//
//	public void setPanCard(String panCard) {
//		this.panCard = panCard;
//	}

	public String getCandidateEmailID() {
		return candidateEmailID;
	}

	public void setCandidateEmailID(String candidateEmailID) {
		this.candidateEmailID = candidateEmailID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	@Override
	public String toString() {
		return "Candidate [candidateEmailID=" + candidateEmailID + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", mobileNumber=" + mobileNumber + ", status=" + status
				+ ", requirementID=" + requirementID + ", interview=" + interview + "]";
	}



	public Candidate(String candidateEmailID, String firstName, String lastName, String mobileNumber, String status,
			String requirementID) {
		super();
		this.candidateEmailID = candidateEmailID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.status = status;
		this.requirementID = requirementID;
	}	

}
